/*******************************************************************************
 * Name        : sum.h
 * Author      : Max Shi and Hamzah Nizami
 * Date        : 3/6/2020
 * Description : Header of libsum.so
 * Pledge : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#ifndef SUM_H_
#define SUM_H_

/* Function prototype */
int sum_array(int *array, const int length);

#endif
